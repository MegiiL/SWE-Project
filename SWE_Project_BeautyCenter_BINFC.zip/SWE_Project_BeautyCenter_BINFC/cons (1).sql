-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2023 at 07:25 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cons`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phonenr` int(50) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `available` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `name`, `surname`, `phonenr`, `date`, `time`, `available`) VALUES
(11, 'Flo', 'Flower', 857394, '2023-06-07', '10:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-16', '09:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-15', '14:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-08', '09:00:00.000000', 0),
(9, 'Ola', 'loa', 2147483647, '2023-06-10', '11:00:00.000000', 0),
(9, 'Ola', 'loa', 2147483647, '2023-06-04', '09:00:00.000000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `booknails`
--

CREATE TABLE `booknails` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phonenr` int(50) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `available` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booknails`
--

INSERT INTO `booknails` (`id`, `name`, `surname`, `phonenr`, `date`, `time`, `available`) VALUES
(11, 'Flo', 'Flower', 857394, '2023-06-03', '12:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-04', '09:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-02', '14:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-16', '14:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-17', '13:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-15', '11:00:00.000000', 0),
(11, 'Flo', 'Flower', 857394, '2023-06-16', '09:00:00.000000', 0),
(9, 'Ola', 'loa', 2147483647, '2023-06-08', '11:00:00.000000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenr` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `service` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `surname`, `email`, `phonenr`, `username`, `password`, `service`) VALUES
(1, 'Ana', 'Loka', 'analoka@gmail.com', 2147483647, 'anaa1', 'ana123ana', 'lashes'),
(2, 'Mira', 'Alia', 'miraa@gmail.com', 698325565, 'miraalia', 'miraalia123', 'nails');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `surname` varchar(225) NOT NULL,
  `dbirth` date NOT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `phonenr` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `dbirth`, `email`, `username`, `password`, `phonenr`) VALUES
(9, 'Ola', 'loa', '2023-05-19', 'olalao@gmail.com', 'olaoo', 'd2ea25d1fa2faa1d058aff53e720115b', 2147483647),
(10, 'Ken', 'Kel', '2023-05-23', 'kenkel@gmail.com', 'keni', '07796bb2fe08f0f8b220d71fa249125c', 746528333),
(11, 'Flo', 'Flower', '2023-06-14', 'flower@gmail.com', 'flo', 'f1b76b8a7b101a2b24c9bba5fb167d10', 857394);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
