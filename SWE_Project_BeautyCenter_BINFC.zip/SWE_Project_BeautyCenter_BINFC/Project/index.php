<?php  
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> BEAUTY CENTER </title>
        <style>
body {
  background-image: url('https://www.iconic-world.com/files/uploads/produktbilder/iaia/2022/IAIA2022-9845-1.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}

.active{
	color: black;
  font-size: 20px;

}
.row{
  display: flex;
  align-items: center;
  padding: 50px;
  margin: 100px auto;
}
.col{
  flex-basis: 50%;
}

h1{
  color:#fff;
  font-size:20px;
}
p{
  color: #fff;
  font-size: 13px;
  line-height:15px;
}
h5{
  text-align: center;
  color: #fff;
  font-weight: bolder;
}

.card{
  width: 200px;
  height: 230px;
  display: inline-block;
  border-radius: 10px;
  padding: 15px 25px;
  box-sizing: border-box;
  cursor: pointer;
  margin: 10px 15px;
  background-image:url(https://i.pinimg.com/236x/af/de/62/afde6226c9eba206ae7343c196324816.jpg);
  background-size: cover;
  transition: transform 0.5;
}

.card1{
  background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-jXUO93J6Ofo1W4tHjx92fboDXzncEUNgYA&usqp=CAU);
}

.card2{
  background-image:url(https://falseeyelashes.co.uk/cdn/shop/products/dose-of-lashes-3d-faux-mink-lashes-baddie-2_1024x1024.jpg?v=1612872683);
}

.card3{
  background-image:url(https://i.pinimg.com/736x/bd/6a/79/bd6a790e08eb38960233412bbcf69c8b.jpg);
}

.card4{
  background-image:url(https://i.pinimg.com/736x/9c/78/e4/9c78e44afb08895e66a803369449fc8b.jpg);
}
.card:hover{
  transform: translateY(-10px);
}
</style>

    </head>
    
    <body>
      
  

        </div>

        <div class="menu">
        <a class="active" href="#homepage">Beauty Center </a>
        <a class="active" href="photos.php">Photos</a>
            <a class="active" id="registermenu" href="register.php">Register</a>
            <a class="active" id="loginmenu" href="login.php" style="margin-left: 57%;"> Client Login</a>
            <a class="active" id="loginmenu" href="techlogin.php">N/L Technician Login</a>
     
        </div>
       


        <div class="row">
          <div class="col">
          <h1> Welcome to Beauty Center! </h1>
          <p> Your ultimate destination for all things beauty and wellness. We are delighted to bring you a unique and rejuvenating experience that combines state-of-the-art treatments with a serene and luxurious atmosphere. At our beauty center, we understand that self-care is essential for both your inner and outer well-being. That's why our team of expert professionals is dedicated to providing you with personalized services tailored to your specific needs.  </p>
          </div>
          <div class="col">
          
            <div class="card card1">
          <h5> Beauty </h5>
            </div>

         <div class="card card2">
         <h5> Creativity </h5>
         </div>

          <div class="card card3">
         <h5> Aesthetic </h5>
          </div>

          <div class="card card4">
          <h5> Elegance </h5>
          </div>
            
 
        </div>
</div>

       


<?php include("inc/footer.php"); ?>