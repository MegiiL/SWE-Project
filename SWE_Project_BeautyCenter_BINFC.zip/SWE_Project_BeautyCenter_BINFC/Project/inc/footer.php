<style>
footer {
	position: fixed;
	width: 100%;
	left: 0;
	bottom: 0;
	background-color:#C0C0C0;
	color: black;
}
footer p
{
    text-decoration: none;
    color:white;
    font-size: 22px;
}
</style>

<footer>
<p style= "text-align: center;">Copyright &copy; 2023 Beauty Center.</p> 
<span style="text-align: left"> &#9993; beauty.center@gmail.com </span>
<span style="margin-left: 30%;"> &#9742; 0693583933 </span>
<span style="margin-left: 35.8%;"> &#10224; Durres,Albania </span>
	
</footer>
  