<?php
    session_start();
    require 'config/database.php';
    
    if(!empty($_SESSION["id"])) {
        header("Location: myprofile.php");
        exit();
    }
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="style.css">
        <style>
            body{
                background-image: url('https://www.iconic-world.com/files/uploads/produktbilder/iaia/2022/IAIA2022-9845-1.jpg');
                padding: 0;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
                background-size: cover; 
            }
            a{
             color: black;
             font-size: 20px;
            }
        </style>
    </head>

    <body id="login_body">
        <div class="menu">
        <a class="active" href="index.php">Beauty Center</a>
        <a href="photos.php">Photos</a>
            <a id="registermenu" href="register.php">Register</a>
            
        </div>

        <br>

        <b style="color: black; font-size: 30px; text-decoration: underline;"> Client Login</b>
        <br><br>

        <br>

        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">

        <br>

            <div id='loginp'>
                <label for="usernameemail">Username or Email:</label>
                <input type="text" value="" id="usernameemail" name="usernameemail" placeholder="Enter your username..." required maxlength="25" style="color:blue;">
            </div>

        <br>

            
            <div>
                <label for="pass">Password:</label>
                <input type="password" value="" id="pass" name="password" placeholder="Enter your password..." required maxlength="15" style="color:blue;">
                <span id='message'></span>
            </div>

        <br>


     
<?php
   
   if(isset($_POST["login"])) {
    $usernameemail = $_POST["usernameemail"];
    $password = $_POST["password"];
    $password = md5($password);
    
    $result = mysqli_query($conn, "SELECT * FROM users WHERE username = '$usernameemail' OR email = '$usernameemail'");
    $row = mysqli_fetch_assoc($result);
    
    if(mysqli_num_rows($result) > 0) {
        if($password == $row['password']) {
            $_SESSION["logedin"] = true;
            $_SESSION["id"] = $row["id"];
            echo ("<script> alert('Successful login') </script>");
            header("Location: myprofile.php");
            exit();
        }
        else {
            echo "<p style=\"font-size: 20px; color: red;\">Password is incorrect!<p>";
        }
    }
    else {
        echo "<p style=\"font-size: 20px; color: red;\">Username or Email is incorrect!<p>";
    }
}
?>



            <div>
                <input type="submit" name="login" value="Login">
                &nbsp;&nbsp;<span id="span1">If you are not registered yet, <a id="reglink" href="register.php" target="_blank">Click Here.</a></span>
            </div>
        </form>
     
    
    </body>
</html>