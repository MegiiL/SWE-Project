<?php

session_start();

require "config/database.php";

if(!empty($_SESSION["id"])){
    $id = $_SESSION["id"];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
    $row = mysqli_fetch_assoc($result);
} else {
    header("Location: login.php");
}

$duration = 60;
$cleanup = 0;
$start = "09:00";
$end = "15:00";

function timeslots($duration, $cleanup, $start, $end)
{
    $start = new DateTime($start);
    $end = new DateTime($end);
    $interval = new DateInterval("PT" . $duration . "M");
    $cleanupInterval = new DateInterval("PT" . $cleanup . "M");
    $slots = array();

    for ($intStart = $start; $intStart < $end; $intStart->add($interval)->add($cleanupInterval)) {
        $endPeriod = clone $intStart;
        $endPeriod->add($interval);
        if ($endPeriod > $end) {
            break;
        }
        $slots[] = $intStart->format("H:iA") . "-" . $endPeriod->format("H:iA");
    }
    return $slots;
}

// Check if a date is before the current day
function isPastDate($date)
{
    $currentDate = new DateTime();
    $selectedDate = new DateTime($date);
    return $selectedDate < $currentDate;
}

$dt = new DateTime;
$week = $dt->format('W');
$year = $dt->format('o');

if (isset($_GET['week'])) {
    $selectedWeek = $_GET['week'];
    if ($selectedWeek >= $week && $selectedWeek <= ($week + 2)) {
        $week = $selectedWeek;
    }
}

$dt->setISODate($year, $week);
$month = $dt->format('F');
$year = $dt->format('Y');


?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title> Lashes </title>
     

    <style>
            h2{
                text-align: center;
            }

            body{    

                background-image: url(https://wallpaperaccess.com/full/2133455.jpg);

                padding: 0;

                background-repeat: no-repeat;

                background-attachment: fixed;

                background-position: center;

                background-size: cover;

            }
            .active{
                color: black;
            }
           

        </style>

</head>

<body>

<a class="active" href="myprofile.php" style="margin-left: 42%;">My Profile </a>
<a class="active" href="myreservations.php" >My reservations </a>

<a class="active" id="registermenu" href="logout.php">Logout</a>

    <h2>Book Your Lash Appointment</h2>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <center>
                    <h2><?php echo "$month $year" ?></h2>
                    <a class="btn btn-info btn-xs" href="<?php echo $_SERVER['PHP_SELF'] . '?week=' . ($week - 1); ?>">Prev
                        Week</a>
                    <!--Previous week-->
                    <?php if ($week < ($dt->setISODate($year, $week)->format('W') + 2)) : ?>
                        <a class="btn btn-info btn-xs" href="<?php echo $_SERVER['PHP_SELF'] . '?week=' . ($week + 1); ?>">Next
                            Week</a>
                        <!--Next week-->
                    <?php endif; ?>
                </center>
                <table class="table table-bordered">
                    <tr class="text-primary">
                        <?php
                        $dt->setISODate($year, $week);
                        for ($i = 0; $i < 7; $i++) {
                            if ($dt->format('d M Y') == date('d M Y')) {
                                echo "<td>" . $dt->format('l') . "<br>" . $dt->format('d M Y') . "</td>\n";
                            } else {
                                echo "<td>" . $dt->format('l') . "<br>" . $dt->format('d M Y') . "</td>\n";
                            }
                            $dt->modify('+1 day');
                        }
                        ?>
                    </tr>
                    <?php
                    $timeslots = timeslots($duration, $cleanup, $start, $end);
                    foreach ($timeslots as $ts) {
                        echo "<tr>\n";
                        $dt->setISODate($year, $week);
                        for ($i = 0; $i < 7; $i++) {
                            $date = $dt->format('Y-m-d');
                            $buttonText = isPastDate($date) ?  "Unavailable"   : $ts;

                            

                            $isSlotBooked = false;
                            $checkBookingQuery = mysqli_query($conn, "SELECT * FROM book WHERE date = '$date' AND time = '$ts'");
                            if (mysqli_num_rows($checkBookingQuery) > 0) {
                                $isSlotBooked = true;
                            }

                          
        echo "<td>";
        if ($isSlotBooked) {
            echo "<button class=\"btn btn-danger btn-xs timeslot-btn\" disabled>" . $buttonText . "</button>";
        } else {
            $isPast = isPastDate($date);
            $buttonClass = $isPast ? "btn btn-secondary btn-xs timeslot-btn" : "btn btn-info btn-xs timeslot-btn";
            $buttonData = $isPast ? "" : "data-date=\"$date\" data-timeslot=\"$ts\"";
            $buttonDisabled = $isPast ? "disabled" : "";
            echo "<button class=\"$buttonClass\" $buttonData $buttonDisabled>" . $buttonText . "</button>";
        }
        echo "</td>\n";
        $dt->modify('+1 day');
                        }
                        echo "</tr>\n";
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Form Modal -->
    <div class="modal fade" id="appointmentModal" tabindex="-1" role="dialog" aria-labelledby="appointmentModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointmentModalLabel">Book Appointment</h4>
                </div>
                <div class="modal-body">
                    <form id="appointmentForm" method="post" action="reserve.php">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="surname">Surname</label>
                            <input type="text" class="form-control" id="surname" name="surname" value="<?php echo $row['surname']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phonenr">Phone Number</label>
                            <input type="text" class="form-control" id="phonenr" name="phonenr" value="<?php echo $row['phonenr']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="text" class="form-control" id="date" name="date" readonly required>
                        </div>
                        <div class="form-group">
                            <label for="time">Time Slot</label>
                            <input type="text" class="form-control" id="time" name="time" readonly required>
                        </div>
                        <button type="submit" class="btn btn-primary">Book</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(document).ready(function() {
        $('.timeslot-btn').click(function() {
            var date = $(this).data('date');
            var timeslot = $(this).data('timeslot');
            $('#date').val(date);
            $('#time').val(timeslot);
            $('#appointmentModal').modal('show');
        });

        $('#appointmentForm').submit(function(e) {
            e.preventDefault(); // Prevent the form from submitting
            // Submit the form asynchronously
            
           $.ajax({
              type: 'POST',
           url: $(this).attr('action'),
              data: $(this).serialize(),
              success: function(response) {
                     // Handle the success response if needed
                     // For example, display a success message
                   if (response === 'success') {
                       alert('Appointment booked successfully!');
                       $('#appointmentModal').modal('hide');
                   } else if (response === 'occupied') {
                       alert('The selected time slot is already occupied. Please choose another one.');
                   } else {
                       alert('Done');
                   }
               },
               error: function() {
                    // Handle the error response if needed
                    // For example, display an error message
                  alert('An error occurred. Please try again.');
             }
           });
       });
    
    });
</script>
</body>

</html>
