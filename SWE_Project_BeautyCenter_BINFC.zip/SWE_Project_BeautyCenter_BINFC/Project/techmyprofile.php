<?php

    session_start();

    require "config/database.php";

    if(!empty($_SESSION["id"])){

        $id = $_SESSION["id"];

        $result = mysqli_query($conn, "SELECT * FROM employee WHERE id = $id");

        $row = mysqli_fetch_assoc($result);

      }

      else

        header("Location: login.php");

?>

<!DOCTYPE html>

<html lang="en">

    <head>

        <meta charset="UTF-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>My Profile</title>

        

        <style>
            h2{
                text-align: center;
            }

            body{    

                background-image: url(https://wallpaperaccess.com/full/2133455.jpg);

                padding: 0;

                background-repeat: no-repeat;

                background-attachment: fixed;

                background-position: center;

                background-size: cover;

            }
            .active{
                color: black;
            }
           

        </style>

    </head>



    <body>

 



        <div class="menu">

            <a class="active" href="#myprofile" style="margin-left: 40%;">My Profile</a>

            <a class="active" href="clientsreservation.php" > Client's Reservation </a>

            <a class="active" id="registermenu" href="logout.php">Logout</a>


        </div>


    <br>



    

        <div>

    <br>

            <h2>

                First Name: <span><?php echo $row["name"]; ?></span>

            </h2>

    <br>

            <h2>

                Last Name: <span><?php echo $row["surname"]; ?></span>

            </h2>


            <h2>

                Email: <span><?php echo $row["email"]; ?></span>

            </h2> 

    <br>

            <h2>

                Phone Number: <span><?php echo $row["phonenr"]; ?></span>

            </h2> 

            <br>

            <h2>

                Service: <span><?php echo $row["service"]; ?></span>

            </h2> 

    <br>

        </div>



        

    </body>

</html>