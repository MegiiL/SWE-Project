<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Photos</title>
        <style>
          body {
        background-image: url('https://www.iconic-world.com/files/uploads/produktbilder/iaia/2022/IAIA2022-9845-1.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 100%;
}
          a{
                color: black;
                font-size: 20px;
            }
     

          .container1{
            width:90%;
            padding: 20px;
            margin: 100px auto;
            display: flex;
            flex-direction: row;
            justify-content: center;
          }

          .box{
            width: 250px;
            margin: 0 10px;
            box-shadow: 0 0 20px 2px rgba(0, 0, 0, .1);
            transition: 1s;
          }

          .box img{
            display: block;
            height:100%;
            width:100%;
            border-radius: 5px;
          }

          .box:hover{
            transform:scale(1.3);
            z-index:2;
          }
      .container{
        max-width: 1500px;
        margin:auto;
        background: #f2f2f2;
        overflow:auto;
        padding:20px;

      }
      .gallery{
        margin:5px;
        border: 1px solid #ccc;
        float:left;
        width:390px;
      }

      .gallery img{
        width:100%;
        height:auto;
      }
      
      .desc{
        padding:15px;
        text-align:center;
        font-weight: bold;
      }

          
          </style>
    </head>
    
    
    <body>
    
    <div class="menu">
            <a href="index.php">Beauty Center</a>
            <a class="active" href="#homepage">Photos</a>
            <a id="registermenu" href="register.php">Register</a>
            <a class="active" id="loginmenu" href="login.php" style="margin-left: 57%;"> Client Login</a>
            <a class="active" id="loginmenu" href="techlogin.php">N/L Technician Login</a>
        </div>
        

        <div class="container1">
          <div class="box">
            <img src="https://i.pinimg.com/564x/8c/8d/60/8c8d6025d7f1e3f3aac9c885cf365c06.jpg">
            </div>
            <div class="box">
            <img src="https://i.pinimg.com/564x/97/4a/1a/974a1aaa763c6995bf7a5f126e4defec.jpg">
            </div>
            <div class="box">
            <img src=" https://i.pinimg.com/564x/e5/e3/95/e5e3957183c2cc680a39927d6f4b3bc1.jpg">
            </div>
            <div class="box">
            <img src="https://i.pinimg.com/564x/6a/7b/d2/6a7bd26ad09561a322786ab849c5c91a.jpg">
            </div>
            <div class="box">
            <img src="https://i.pinimg.com/564x/6a/2b/7b/6a2b7b830c6a58f300ac3b866e141e69.jpg">
            </div>
          </div>
         
          


            <div class="container">

            <div class="gallery">
              <img src="https://i.pinimg.com/564x/8d/71/8a/8d718a1c25b519898dd0758af064c25c.jpg">
              <div class="desc"> Elegance </div>
        </div>

        <div class="gallery">
              <img src="https://i.pinimg.com/564x/4c/b9/4b/4cb94bb3cf27251359dcb24e90d213b5.jpg">
              <div class="desc"> Beauty </div>
        </div>

        <div class="gallery">
              <img src="https://i.pinimg.com/564x/b9/a3/0b/b9a30bd7ef6a982c23e8a9ef450103e2.jpg">
              <div class="desc"> Aesthetic</div>
        </div>




    </body>
</html>