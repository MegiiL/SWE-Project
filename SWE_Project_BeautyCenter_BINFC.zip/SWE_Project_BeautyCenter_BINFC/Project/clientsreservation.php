<?php
session_start();
require "config/database.php";

if (!empty($_SESSION["id"])) {
    $id = $_SESSION["id"];

    if ($id == 1) {
        $result = mysqli_query($conn, "SELECT * FROM book WHERE YEARWEEK(date) = YEARWEEK(CURDATE()) ORDER BY date ASC");
    } else if ($id == 2) {
        $result = mysqli_query($conn, "SELECT * FROM booknails WHERE YEARWEEK(date) = YEARWEEK(CURDATE()) ORDER BY date ASC");
    }

} else {
    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client's Reservations</title>

    <style>
        h2 {
            text-align: center;
        }

        body {
            background-image: url(https://wallpaperaccess.com/full/2133455.jpg);
            padding: 0;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            background-size: cover;
        }

        .active {
            color: black;
        }

        .reservation-table {
            margin: auto;
            border-collapse: collapse;
            text-align: center;
        }

        .reservation-table th,
        .reservation-table td {
            padding: 5px;
        }
    </style>
</head>

<body>
    <div class="menu">
        <a class="active" href="techmyprofile.php" style="margin-left: 45%;">My Profile</a>
        <a class="active" id="registermenu" href="logout.php">Logout</a>
    </div>

    <h2>Client's Reservations:</h2>

    <table class="reservation-table">
        <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Phone number</th>
            <th>Date</th>
            <th>Time</th>

        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row["name"]; ?></td>
                <td><?php echo $row["surname"]; ?></td>
                <td><?php echo $row["phonenr"]; ?></td>
                <td><?php echo $row["date"]; ?></td>
                <td><?php echo $row["time"]; ?></td>
            </tr>
        <?php } ?>
    </table>

</body>

</html>



