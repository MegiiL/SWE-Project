<?php
session_start();

require "config/database.php";

if (!empty($_SESSION["id"])) {
    $id = $_SESSION["id"];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
    $row = mysqli_fetch_assoc($result);
} else {
    header("Location: login.php");
}

if (!empty($_POST)) {
    // Retrieve form data
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $phonenr = $_POST['phonenr'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    // Check if the time slot is already booked
   $query = "SELECT * FROM book WHERE date = '$date' AND time = '$time'";
    $result = mysqli_query($conn, $query);

   if (mysqli_num_rows($result) > 0) {
         //The time slot is already booked
      echo 'occupied';
      exit;
   }

    // Insert the appointment into the book table
    $query = "INSERT INTO book (id, name, surname, phonenr, date, time) VALUES ('$id', '$name', '$surname', '$phonenr', '$date', '$time')";
    if (mysqli_query($conn, $query)) {
        // Appointment booked successfully
        echo 'success';
        exit;
    } else {
        // Error occurred during booking
        echo 'error';
        exit;
    }
} else {
    // Invalid request, redirect to the booking page
    header("Location: index.php");
    exit;
}
?>
