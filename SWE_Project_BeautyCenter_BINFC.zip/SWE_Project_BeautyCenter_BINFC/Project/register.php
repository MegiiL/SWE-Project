<?php 
    include('config/database.php'); 

    if(isset($_POST["name"]))
    {
        $name = $_POST["name"];
        $surname = $_POST["surname"];
        $dbirth = $_POST["dbirth"];
        $email = $_POST["email"];
        $username = $_POST["username"];
        $pass = $_POST["pass"];
        $pass = md5($pass); //encpt
        $phonenr = $_POST["phonenr"];

        $dublicate = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' OR email = '$email'");
        if(mysqli_num_rows($dublicate) > 0)
        {
            echo ("<script> alert('USERNAME OR EMAIL IS ALREADY TAKEN!') </script>");
        }
        else
        {
            $query = "INSERT INTO users (id, name, surname, dbirth, email, username, password, phonenr) VALUES ('', '$name', '$surname', '$dbirth', '$email', '$username', '$pass', '$phonenr')";
            mysqli_query($conn, $query);

            echo ("<script> alert('Registration successful') </script>");
            echo ("<script> window.open('index.php', '_blank') </script>");
        }
    }
?>
              

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Register</title>
        
        <style>
            body{    
                background-image: url('https://www.iconic-world.com/files/uploads/produktbilder/iaia/2022/IAIA2022-9845-1.jpg');
                padding: 0;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
                background-size: cover; 
            }
            a{
                color: black;
                font-size: 20px;
            }
        </style>
    </head>

    <body id="regbody">
        <div class="menu">
            <a href="index.php">Beauty Center</a>
            <a href="photos.php">Photos</a>
            <a class="active" id="registermenu" href="#register">Register</a>
            <a class="active" id="loginmenu" href="login.php" style="margin-left: 57%;"> Client Login</a>
            <a class="active" id="loginmenu" href="techlogin.php">N/L Technician Login</a>
        </div>

        
        <br>

        <b style="color: black; font-size: 30px; text-decoration: underline;">Register</b>
        <br><br>



        <form id ='registerform' name="register" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" style="font-size: 18px;"> 
            
        <br>
            <div>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter your name..."  maxlength="25" style="color:blue;">
            </div>

        <br>


            <div>
                <label for="surname">Surname:</label>
                <input type="text" id="surname" name="surname" placeholder="Enter your surname..."  maxlength="25" style="color:blue;">
            </div>

        <br>


       

            <div>
                <label for="dbirth">Date of birth:</label>
                <input type="date" id="dbirth" name="dbirth" placeholder="Enter your birthdate..."  style="color:blue;">
            </div>

        <br>

            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email..."  style="color:blue;">
            </div>

        <br>

            <div>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your username..."  maxlength="25" style="color:blue;">
            </div>

        <br>

            <div>
                <label for="pass">Password:</label>
                <input type="password" id="pass"  onkeyup="check();" name="pass" placeholder="Enter your password..."  maxlength="15" style="color:blue;">
            </div>

            <div>
                <label for="phone">Phone:</label>
                <input type="number" id="phonenr"  name="phonenr" placeholder="Enter your number..."  maxlength="15" style="color:blue;">
            </div>
        
        <br>

            <div>
                <label for="confpass">Confirm Passowrd:</label>
                <input type="password" id="confpass" onkeyup="check();" name="confpass" placeholder="Confirm your password..."  maxlength="15" style="color:blue;">
                <span id='message'></span>
            </div>

        <br><br><br>

            <div>
                <input type="button" onclick="validateForm();" name="buttonsub" value="Submit" id="buttonsub">
                <input type="reset" value="Reset" id='reset' >
            </div>

        </form>


            
        

        <script type="text/javascript">
 function check () 
            {
                if(document.getElementById('pass').value == '' || document.getElementById('confpass').value == '' )
                {
                    if( document.getElementById('confpass').value == '' &&  document.getElementById('pass').value != '')
                    {
                        document.getElementById('message').style.color = "red";
                        document.getElementById('message').style.fontWeight = "bold"
                        document.getElementById('message').style.fontSize = "20px";
                        document.getElementById('message').innerHTML = "You must confirm your password!";
                        document.getElementById('buttonsub').disabled = true;  
                    }
                    else
                    {
                        document.getElementById('message').innerHTML = "";
                        document.getElementById('buttonsub').disabled = true;  
                    }
                }
                else if (document.getElementById('pass').value == document.getElementById('confpass').value) 
                {
                    document.getElementById('message').style.color = "black";
                    document.getElementById('message').style.fontWeight = "normal"
                    document.getElementById('message').style.fontSize = "20px";
                    document.getElementById('message').innerHTML = "Matching ✅";
                    document.getElementById('buttonsub').disabled = false;
                } 
                else 
                {
                    document.getElementById('message').style.color = "red";
                    document.getElementById('message').style.fontWeight = "bold"
                    document.getElementById('message').style.fontSize = "20px";
                    document.getElementById('message').innerHTML = "Not matching! ❌";
                    document.getElementById('buttonsub').disabled = true;
                }
            }

               /* 
           I have made boolean functions to check if each field is correct then in 
            validate function i check everything to find the mistake made or to submit if everything looks good.
        */
        function passCheck ()
            {
                var pass = document.getElementById('pass').value;

                if (pass.length >= 6)
                    return true;

                else
                    return false;
            }
            
            function nameCheck ()
            {
                var name = document.getElementById('name').value;

                if (name != null && name !== "")
                    return true;

                else
                    return false;
            }

            function dbirthCheck ()
            {
                var dbirth = document.getElementById('dbirth').value;

                if (dbirth != null && dbirth !== "")
                    return true;

                else
                    return false;
            }

            function surnameCheck ()
            {
                var surname = document.getElementById('surname').value;

                if (surname != null && surname !== "")
                    return true;

                else
                    return false;
            }
            function usernameCheck ()
            {
                var username = document.getElementById('username').value;

                if (username != null && username !== "")
                    return true;

                else
                    return false;
            }

            function emailCheck ()
            {
                var emailAdress = document.getElementById('email').value;
                var atIndex = emailAdress.indexOf("@"); // finds the index of '@'
                var dotIndex = emailAdress.indexOf("."); // finds index of "."

                /*  
                    Checking  that @ index cannot be in the begining of email it needs to be position 3 or after, 
                    also dot index needs to be after at least 3 chars after we type the @ sign,
                    also the dot cannot be in the end of email, we got length-1 because we start index from 0 and the last is length-1
                */
                if(atIndex < 1 || dotIndex <= atIndex + 2 || dotIndex === emailAdress.length - 1) 
                    return false;

                
                return true;
            }



            function validateForm ()
            {



                if (passCheck() && nameCheck() && surnameCheck() && usernameCheck() && emailCheck() && dbirthCheck())
                {     
                    document.getElementById('registerform').submit();

                    // Now we make the fields empty 
                    document.getElementById("name").value = "";
                    document.getElementById("surname").value = "";
                    document.getElementById("username").value = "";
                    document.getElementById("dbirth").value = "";
                    document.getElementById("pass").value = "";
                    document.getElementById("email").value = "";

                }
                
                else
                {
                    alert("Your form cannot be submitted.");
                    if(!passCheck())
                    {
                        alert("Password must be at least 6 characters");
                        document.getElementById("pass").value = "";
                        document.getElementById("pass").focus();

                    }

                    if(!emailCheck())
                    {
                        alert("Email is not in the right format");
                        document.getElementById("email").value = "";
                        document.getElementById("email").focus();

                    }

                    if(!usernameCheck())
                    {
                        alert("Username field cannot be empty");
                        document.getElementById("username").focus();

                    }

                    if(!dbirthCheck())
                    {
                        alert("Date of birth field cannot be empty");
                        document.getElementById("dbirth").focus();

                    }

                    if(!nameCheck())
                    {
                        alert("Name field cannot be empty");
                        document.getElementById("name").focus();
                    }
                    alert("The info cannot be saved in databse.");
                }
            }

        </script>
    
    </body>
</html>